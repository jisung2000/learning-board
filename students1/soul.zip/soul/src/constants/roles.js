module.exports = {
  DEFAULT_ROLE: 'default',
};
